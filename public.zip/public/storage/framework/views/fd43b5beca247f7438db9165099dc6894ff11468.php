<div class="sticky-toolbar">	    
    <a id="chat-popup" href="#" data-bs-toggle="tooltip" data-bs-placement="left" title="Live Chat" class="waves-effect waves-light btn btn-warning btn-flat btn-sm">
        <span class="icon-Group-chat"><span class="path1"></span><span class="path2"></span></span>
    </a>
</div>
<?php /**PATH C:\wamp64\www\AccountingSoftware\resources\views/common/stickytoolbar.blade.php ENDPATH**/ ?>