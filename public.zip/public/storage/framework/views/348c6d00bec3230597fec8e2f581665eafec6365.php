<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="author" content="">
<link rel="icon" href="<?php echo e(asset('storage/images/favicon.ico')); ?>">

<title><?php echo $__env->yieldContent('title' ,'CRMi - Dashboard'); ?></title>

<!-- Vendors Style-->
<link rel="stylesheet" href="<?php echo e(asset('storage/src/css/vendors_css.css')); ?>">
  
<!-- Style-->  
<link rel="stylesheet" href="<?php echo e(asset('storage/src/css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('storage/src/css/skin_color.css')); ?>">
<?php /**PATH C:\wamp64\www\AccountingSoftware\resources\views/common/head.blade.php ENDPATH**/ ?>