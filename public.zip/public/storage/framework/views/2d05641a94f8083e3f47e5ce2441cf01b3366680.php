<script src="<?php echo e(asset('storage/src/js/vendors.min.js')); ?>"></script>
<script src="<?php echo e(asset('storage/src/js/pages/chat-popup.js')); ?>"></script>
<script src="<?php echo e(asset('storage/assets/icons/feather-icons/feather.min.js')); ?>"></script>
<script src="<?php echo e(asset('storage/assets/vendor_components/datatable/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('storage/assets/vendor_components/apexcharts-bundle/irregular-data-series.js')); ?>"></script>
<script src="<?php echo e(asset('storage/assets/vendor_components/apexcharts-bundle/dist/apexcharts.js')); ?>"></script>

<!-- CRMi App -->
<script src="<?php echo e(asset('storage/src/js/template.js')); ?>"></script>
<script src="<?php echo e(asset('storage/src/js/pages/analysis.js')); ?>"></script>
<script src="<?php echo e(asset('storage/src/js/pages/data-table.js')); ?>"></script>
<script src="<?php echo e(asset('storage/assets/vendor_components/jquery-steps-master/build/jquery.steps.js')); ?>"></script>
<script src="<?php echo e(asset('storage/assets/vendor_components/jquery-validation-1.17.0/dist/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('storage/assets/vendor_components/sweetalert/sweetalert.min.js')); ?>"></script>
<script src="<?php echo e(asset('storage/src/js/pages/steps.js')); ?>"></script>
<?php /**PATH C:\wamp64\www\AccountingSoftware\resources\views/common/script.blade.php ENDPATH**/ ?>